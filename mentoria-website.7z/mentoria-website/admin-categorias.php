<?php
$pageTitle = 'Gerenciar Categorias - MentorHub';
require_once 'config/database.php';
require_once 'includes/header.php';

if (!estaLogado() || $_SESSION['usuario_tipo'] !== 'mentor') {
    header('Location: index.php');
    exit;
}

$conn = getConnection();
$success = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
    $nome = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $icone = trim($_POST['icone'] ?? '');
    
    if (empty($nome)) {
        $errors[] = 'Nome da categoria é obrigatório';
    } elseif (strlen($nome) < 3) {
        $errors[] = 'Nome deve ter no mínimo 3 caracteres';
    } elseif (strlen($nome) > 50) {
        $errors[] = 'Nome deve ter no máximo 50 caracteres';
    }
    
    if (empty($icone)) {
        $errors[] = 'Ícone é obrigatório';
    }
    
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("SELECT id FROM categorias WHERE nome = ?");
            $stmt->execute([$nome]);
            
            if ($stmt->fetch()) {
                $errors[] = 'Já existe uma categoria com este nome';
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO categorias (nome, descricao, icone)
                    VALUES (?, ?, ?)
                ");
                $stmt->execute([$nome, $descricao, $icone]);
                $success = 'Categoria cadastrada com sucesso!';
                
                $_POST = [];
            }
        } catch (Exception $e) {
            $errors[] = 'Erro ao cadastrar categoria: ' . $e->getMessage();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'excluir') {
    $categoriaId = intval($_POST['categoria_id'] ?? 0);
    
    if ($categoriaId > 0) {
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM mentorias WHERE categoria_id = ?");
            $stmt->execute([$categoriaId]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $errors[] = "Não é possível excluir esta categoria pois existem {$count} mentoria(s) vinculada(s) a ela.";
            } else {
                $stmt = $conn->prepare("DELETE FROM categorias WHERE id = ?");
                $stmt->execute([$categoriaId]);
                $success = 'Categoria excluída com sucesso!';
            }
        } catch (Exception $e) {
            $errors[] = 'Erro ao excluir categoria: ' . $e->getMessage();
        }
    }
}

$categorias = $conn->query("
    SELECT c.*, COUNT(m.id) as total_mentorias
    FROM categorias c
    LEFT JOIN mentorias m ON c.id = m.categoria_id
    GROUP BY c.id
    ORDER BY c.nome
")->fetchAll();

?>

<style>
.admin-container {
    padding: 2rem 0;
}

.form-section {
    background: var(--bg-primary);
    padding: 2rem;
    border-radius: var(--radius-lg);
    margin: 2rem 0;
    box-shadow: var(--shadow-sm);
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: var(--text-primary);
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid var(--border-color);
    border-radius: var(--radius-md);
    font-size: 1rem;
    font-family: inherit;
    background: var(--bg-secondary);
    color: var(--text-primary);
}

.form-group textarea {
    min-height: 100px;
    resize: vertical;
}

.categorias-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
    margin-top: 2rem;
}

.categoria-card {
    background: var(--bg-primary);
    padding: 1.5rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    transition: transform 0.2s;
    position: relative;
}

.categoria-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.categoria-icone {
    font-size: 3rem;
    text-align: center;
    margin-bottom: 1rem;
}

.categoria-nome {
    font-size: 1.25rem;
    font-weight: 600;
    color: var(--text-primary);
    text-align: center;
    margin-bottom: 0.5rem;
}

.categoria-descricao {
    color: var(--text-secondary);
    font-size: 0.9rem;
    text-align: center;
    margin-bottom: 1rem;
}

.categoria-stats {
    text-align: center;
    padding: 0.75rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    margin-bottom: 1rem;
}

.categoria-actions {
    display: flex;
    justify-content: center;
}

.success-message {
    background: #d4edda;
    color: #155724;
    padding: 1rem;
    border-radius: var(--radius-md);
    margin: 1rem 0;
    border: 1px solid #c3e6cb;
}

.error-message {
    background: #f8d7da;
    color: #721c24;
    padding: 1rem;
    border-radius: var(--radius-md);
    margin: 1rem 0;
    border: 1px solid #f5c6cb;
}

.icone-preview {
    font-size: 3rem;
    text-align: center;
    padding: 1rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    margin-top: 0.5rem;
}

.icone-suggestions {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-top: 0.5rem;
}

.icone-btn {
    padding: 0.5rem 1rem;
    background: var(--bg-secondary);
    border: 2px solid var(--border-color);
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1.5rem;
    transition: all 0.2s;
}

.icone-btn:hover {
    border-color: var(--primary-color);
    transform: scale(1.1);
}

.btn-small {
    padding: 0.5rem 1rem;
    font-size: 0.9rem;
}
</style>

<div class="container admin-container">
    <h1>📁 Gerenciar Categorias</h1>
    <p style="color: var(--text-secondary);">Cadastre e gerencie as categorias de mentorias</p>
    
    <?php if ($success): ?>
        <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    
    <?php if (!empty($errors)): ?>
        <div class="error-message">
            <?php foreach ($errors as $error): ?>
                <p><?php echo htmlspecialchars($error); ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <div class="form-section">
        <h2 style="margin-bottom: 1.5rem;">➕ Cadastrar Nova Categoria</h2>
        
        <form method="POST" action="" id="formCadastroCategoria">
            <input type="hidden" name="acao" value="cadastrar">
            
            <div class="form-group">
                <label for="nome">Nome da Categoria *</label>
                <input 
                    type="text" 
                    id="nome" 
                    name="nome" 
                    required 
                    minlength="3"
                    maxlength="50"
                    placeholder="Ex: Desenvolvimento Web"
                    value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>"
                >
                <small style="color: var(--text-secondary);">Mínimo 3 caracteres, máximo 50</small>
            </div>
            
            <div class="form-group">
                <label for="descricao">Descrição</label>
                <textarea 
                    id="descricao" 
                    name="descricao" 
                    placeholder="Breve descrição sobre esta categoria..."
                ><?php echo htmlspecialchars($_POST['descricao'] ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="icone">Ícone (emoji) *</label>
                <input 
                    type="text" 
                    id="icone" 
                    name="icone" 
                    required 
                    maxlength="10"
                    placeholder="Escolha um emoji abaixo ou digite"
                    value="<?php echo htmlspecialchars($_POST['icone'] ?? ''); ?>"
                    oninput="atualizarPreview()"
                >
                
                <div class="icone-preview" id="iconePreview">
                    <?php echo htmlspecialchars($_POST['icone'] ?? '❓'); ?>
                </div>
                
                <p style="margin-top: 1rem; color: var(--text-secondary);">Sugestões de ícones:</p>
                <div class="icone-suggestions">
                    <button type="button" class="icone-btn" onclick="selecionarIcone('💻')">💻</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🎨')">🎨</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('📱')">📱</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('💼')">💼</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🌍')">🌍</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('✍️')">✍️</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('📚')">📚</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🎓')">🎓</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🔬')">🔬</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🎵')">🎵</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🏋️')">🏋️</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🍳')">🍳</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('💡')">💡</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🎯')">🎯</button>
                    <button type="button" class="icone-btn" onclick="selecionarIcone('🚀')">🚀</button>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%;">
                ✅ Cadastrar Categoria
            </button>
        </form>
    </div>
    
    <div style="margin-top: 3rem;">
        <h2 style="margin-bottom: 1.5rem;">📋 Categorias Cadastradas (<?php echo count($categorias); ?>)</h2>
        
        <?php if (empty($categorias)): ?>
            <div style="text-align: center; padding: 3rem; color: var(--text-secondary);">
                <p style="font-size: 3rem;">📁</p>
                <p>Nenhuma categoria cadastrada ainda.</p>
            </div>
        <?php else: ?>
            <div class="categorias-grid">
                <?php foreach ($categorias as $categoria): ?>
                    <div class="categoria-card">
                        <div class="categoria-icone">
                            <?php echo htmlspecialchars($categoria['icone']); ?>
                        </div>
                        <div class="categoria-nome">
                            <?php echo htmlspecialchars($categoria['nome']); ?>
                        </div>
                        <?php if (!empty($categoria['descricao'])): ?>
                            <div class="categoria-descricao">
                                <?php echo htmlspecialchars($categoria['descricao']); ?>
                            </div>
                        <?php endif; ?>
                        <div class="categoria-stats">
                            <strong><?php echo $categoria['total_mentorias']; ?></strong> 
                            mentoria(s)
                        </div>
                        <div class="categoria-actions">
                            <form method="POST" style="display: inline;" onsubmit="return confirmarExclusao(<?php echo $categoria['total_mentorias']; ?>);">
                                <input type="hidden" name="acao" value="excluir">
                                <input type="hidden" name="categoria_id" value="<?php echo $categoria['id']; ?>">
                                <button 
                                    type="submit" 
                                    class="btn btn-outline btn-small" 
                                    style="background: #dc3545; color: white; border-color: #dc3545;"
                                    <?php echo $categoria['total_mentorias'] > 0 ? 'disabled title="Não é possível excluir categorias com mentorias vinculadas"' : ''; ?>
                                >
                                    🗑️ Excluir
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function atualizarPreview() {
    const icone = document.getElementById('icone').value || '❓';
    document.getElementById('iconePreview').textContent = icone;
}

function selecionarIcone(emoji) {
    document.getElementById('icone').value = emoji;
    atualizarPreview();
}

function confirmarExclusao(totalMentorias) {
    if (totalMentorias > 0) {
        alert('Não é possível excluir esta categoria pois existem mentorias vinculadas a ela.');
        return false;
    }
    return confirm('Tem certeza que deseja excluir esta categoria?');
}

document.getElementById('formCadastroCategoria').addEventListener('submit', function(e) {
    const nome = document.getElementById('nome').value.trim();
    const icone = document.getElementById('icone').value.trim();
    
    if (nome.length < 3) {
        e.preventDefault();
        alert('O nome deve ter no mínimo 3 caracteres');
        return false;
    }
    
    if (nome.length > 50) {
        e.preventDefault();
        alert('O nome deve ter no máximo 50 caracteres');
        return false;
    }
    
    if (!icone) {
        e.preventDefault();
        alert('Selecione um ícone para a categoria');
        return false;
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
