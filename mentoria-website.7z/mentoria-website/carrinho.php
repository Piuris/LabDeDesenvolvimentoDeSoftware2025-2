<?php
$pageTitle = 'Carrinho - MentorHub';
require_once 'config/database.php';
require_once 'includes/header.php';

if (!estaLogado()) {
    header('Location: index.php#login');
    exit;
}

$conn = getConnection();
$usuarioId = $_SESSION['usuario_id'];

$stmt = $conn->prepare("
    SELECT c.*, m.titulo, m.descricao, m.preco, m.duracao, 
           cat.icone as categoria_icone, u.nome as mentor_nome
    FROM carrinho c
    JOIN mentorias m ON c.mentoria_id = m.id
    JOIN categorias cat ON m.categoria_id = cat.id
    JOIN usuarios u ON m.mentor_id = u.id
    WHERE c.usuario_id = ?
    ORDER BY c.adicionado_em DESC
");
$stmt->execute([$usuarioId]);
$itens = $stmt->fetchAll();

$total = array_sum(array_column($itens, 'preco'));
?>

<div class="container">
    <h1 style="margin: 2rem 0;">🛒 Meu Carrinho</h1>
    
    <?php if (count($itens) === 0): ?>
        <div style="text-align: center; padding: 4rem; background: var(--bg-primary); border-radius: var(--radius-lg);">
            <div style="font-size: 5rem; margin-bottom: 1rem;">🛒</div>
            <h2>Seu carrinho está vazio</h2>
            <p style="color: var(--text-secondary); margin: 1rem 0;">Explore nossas mentorias e adicione ao carrinho!</p>
            <a href="mentorias.php" class="btn btn-primary">Ver Mentorias</a>
        </div>
    <?php else: ?>
        <div class="cart-items">
            <?php foreach ($itens as $item): ?>
                <div class="cart-item">
                    <div class="cart-item-image card-image" style="width: 100px; height: 100px; font-size: 2rem;">
                        <?php echo $item['categoria_icone']; ?>
                    </div>
                    <div class="cart-item-info">
                        <h3><?php echo htmlspecialchars($item['titulo']); ?></h3>
                        <p style="color: var(--text-secondary); margin: 0.5rem 0;">
                            👤 <?php echo htmlspecialchars($item['mentor_nome']); ?>
                        </p>
                        <p style="color: var(--text-secondary);">⏱️ <?php echo $item['duracao']; ?> minutos</p>
                    </div>
                    <div style="text-align: right;">
                        <p class="card-price">R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></p>
                        <button onclick="removeFromCart(<?php echo $item['mentoria_id']; ?>, this)" 
                                class="btn" style="background: var(--danger-color); color: white; margin-top: 1rem;">
                            🗑️ Remover
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="cart-summary">
            <h2>Resumo do Pedido</h2>
            <div class="summary-row">
                <span>Subtotal (<?php echo count($itens); ?> itens)</span>
                <span>R$ <?php echo number_format($total, 2, ',', '.'); ?></span>
            </div>
            <div class="summary-row">
                <span>Taxa de serviço</span>
                <span>R$ 0,00</span>
            </div>
            <div class="summary-row" style="border-top: 2px solid var(--border-color); margin-top: 1rem; padding-top: 1rem;">
                <strong>Total</strong>
                <strong class="summary-total">R$ <?php echo number_format($total, 2, ',', '.'); ?></strong>
            </div>
            <button class="btn btn-success" style="width: 100%; margin-top: 1.5rem; padding: 1rem;">
                ✓ Finalizar Compra
            </button>
            <a href="mentorias.php" class="btn btn-outline" style="width: 100%; margin-top: 1rem; text-align: center; display: block;">
                ← Continuar Comprando
            </a>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>

<script>
console.log('[v0] Script inline do carrinho carregado');

function removeFromCart(mentoriaId, button) {
    console.log('[v0] removeFromCart chamado para mentoria ID:', mentoriaId);
    
    if (!mentoriaId) {
        console.error('[v0] ID da mentoria inválido');
        showNotification('Erro ao remover item', 'error');
        return;
    }
    
    console.log('[v0] Enviando requisição para remover...');
    
    fetch('api/carrinho-remove.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ mentoria_id: mentoriaId })
    })
    .then(response => {
        console.log('[v0] Resposta recebida:', response);
        return response.json();
    })
    .then(data => {
        console.log('[v0] Dados da resposta:', data);
        if (data.success) {
            showNotification('Item removido do carrinho!', 'success');
            setTimeout(() => {
                window.location.reload();
            }, 500);
        } else {
            showNotification(data.message || 'Erro ao remover item', 'error');
        }
    })
    .catch(error => {
        console.error('[v0] Erro na requisição:', error);
        showNotification('Erro ao remover item do carrinho', 'error');
    });
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'success' ? 'var(--success-color)' : type === 'error' ? 'var(--danger-color)' : 'var(--primary-color)'};
        color: white;
        border-radius: var(--radius-md);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

console.log('[v0] Funções do carrinho definidas');
</script>
