<?php
require_once 'config/database.php';
logout();
header('Location: index.php');
exit;
?>
