<?php
$pageTitle = 'Contato - MentorHub';
require_once 'config/database.php';

$success = false;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = sanitize($_POST['nome']);
    $email = sanitize($_POST['email']);
    $assunto = sanitize($_POST['assunto']);
    $mensagem = sanitize($_POST['mensagem']);
    
    if (empty($nome)) $errors[] = 'Nome é obrigatório';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email inválido';
    if (empty($assunto)) $errors[] = 'Assunto é obrigatório';
    if (empty($mensagem)) $errors[] = 'Mensagem é obrigatória';
    
    if (empty($errors)) {
        $conn = getConnection();
        $stmt = $conn->prepare("
            INSERT INTO contatos (nome, email, assunto, mensagem) 
            VALUES (?, ?, ?, ?)
        ");
        
        if ($stmt->execute([$nome, $email, $assunto, $mensagem])) {
            $para = 'contato@mentorhub.com';
            $titulo = 'Novo Contato - ' . $assunto;
            $corpo = "Nome: $nome\nEmail: $email\n\nMensagem:\n$mensagem";
            $headers = "From: $email\r\nReply-To: $email";
            
            
            $success = true;
        } else {
            $errors[] = 'Erro ao enviar mensagem';
        }
    }
}

require_once 'includes/header.php';
?>

<div class="container">
    <div class="form-container" style="max-width: 700px;">
        <h1>📧 Fale Conosco</h1>
        <p style="color: var(--text-secondary); margin-bottom: 2rem;">
            Tem dúvidas ou sugestões? Entre em contato conosco!
        </p>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                ✅ Mensagem enviada com sucesso! Responderemos em breve.
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $error): ?>
                    <p>❌ <?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" data-validate>
            <div class="form-group">
                <label for="nome">Nome *</label>
                <input type="text" id="nome" name="nome" class="form-control" required
                       value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="email">Email *</label>
                <input type="email" id="email" name="email" class="form-control" required
                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="assunto">Assunto *</label>
                <select id="assunto" name="assunto" class="form-control" required>
                    <option value="">Selecione...</option>
                    <option value="Dúvida" <?php echo ($_POST['assunto'] ?? '') === 'Dúvida' ? 'selected' : ''; ?>>Dúvida</option>
                    <option value="Sugestão" <?php echo ($_POST['assunto'] ?? '') === 'Sugestão' ? 'selected' : ''; ?>>Sugestão</option>
                    <option value="Problema Técnico" <?php echo ($_POST['assunto'] ?? '') === 'Problema Técnico' ? 'selected' : ''; ?>>Problema Técnico</option>
                    <option value="Parceria" <?php echo ($_POST['assunto'] ?? '') === 'Parceria' ? 'selected' : ''; ?>>Parceria</option>
                    <option value="Outro" <?php echo ($_POST['assunto'] ?? '') === 'Outro' ? 'selected' : ''; ?>>Outro</option>
                </select>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="mensagem">Mensagem *</label>
                <textarea id="mensagem" name="mensagem" class="form-control" rows="6" required><?php echo htmlspecialchars($_POST['mensagem'] ?? ''); ?></textarea>
                <span class="error-message"></span>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%;">Enviar Mensagem</button>
        </form>
        
        <div style="margin-top: 3rem; padding: 2rem; background: var(--bg-secondary); border-radius: var(--radius-md);">
            <h3>Outras formas de contato</h3>
            <p style="margin: 1rem 0;">📧 Email: contato@mentorhub.com</p>
            <p style="margin: 1rem 0;">📱 WhatsApp: (11) 99999-9999</p>
            <p style="margin: 1rem 0;">🕒 Horário de atendimento: Seg-Sex, 9h-18h</p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
